// Legend Child component
import React from "react";
// Functional component that receives regionColors as a prop
export default function Legend({ regionColors }) {
  return (
    <div className="map-legend">
      {" "}
      {/* Container for the legend */}
      <h4>Legend</h4> {/* Heading for the legend */}
      {/* Iterate over regionColors object: key = zone name, value = color */}
      {Object.entries(regionColors).map(([zone, color]) => (
        <div key={zone} className="legend-item">
          <span
            className="legend-color"
            style={{ backgroundColor: color }}
          ></span>
          {zone} {/* Display the name of the zone */}
        </div>
      ))}
    </div>
  );
}
