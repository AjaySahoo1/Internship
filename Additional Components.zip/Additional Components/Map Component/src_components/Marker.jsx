import React, { useEffect, useState, useMemo, useRef } from 'react';
import { Marker, Popup, useMap } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-markercluster';
import L from 'leaflet';

// Optional: Fix Leaflet marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

export default function HCPMarker({ hcpData, zoomThreshold}) {
  const map = useMap();
  const [showMarkers, setShowMarkers] = useState(true);
  const popupRef = useRef(null);


  // Zoom-level visibility control
  useEffect(() => {
    const handleZoom = () => {
      setShowMarkers(map.getZoom() >= zoomThreshold);
    };

    map.on('zoomend', handleZoom);
    handleZoom(); // Run on load

    return () => map.off('zoomend', handleZoom);
  }, [map, zoomThreshold]);

  // Global click listener to close popups
  useEffect(() => {
    const handleClickOutside = (e) => {
      const popupEls = document.querySelectorAll('.leaflet-popup');
      const clickedInsidePopup = Array.from(popupEls).some((el) => el.contains(e.target));

      if (!clickedInsidePopup && popupRef.current) {
        map.closePopup(popupRef.current);
        popupRef.current = null;
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [map]);

  // Zone-filtered markers
  const markers = useMemo(() => {
    if (!hcpData?.features || !Array.isArray(hcpData.features)) return null;

    return hcpData.features.map((hcp, idx) => {
      const coords = hcp.geometry?.coordinates;
      if (!Array.isArray(coords) || coords.length !== 2) return null;

      const [lon, lat] = coords;
      const { name, address, city, state } = hcp.properties || {};

      return (
        <Marker key={hcp.id || idx} position={[lat, lon]}>
          <Popup
            eventHandlers={{
              add: (event) => {
                popupRef.current = event.popup;
              },
            }}
          >
            <strong>{name}</strong><br />
            {address}<br />
            {city}, {state}
          </Popup>
        </Marker>
      );
    });
  }, [hcpData]);

  if (!markers || !showMarkers) return null;

  return (
    <MarkerClusterGroup chunkedLoading spiderfyOnMaxZoom={false}
  showCoverageOnHover={false}
  removeOutsideVisibleBounds={true}>{markers}</MarkerClusterGroup>
  );
}