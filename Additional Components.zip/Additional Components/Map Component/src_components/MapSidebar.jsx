// MapSidebar child component
import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChevronDown,
  faChevronRight,
} from "@fortawesome/free-solid-svg-icons";
import "./MapSidebar.css";

export default function MapSidebar({
  zones,
  selectedZips,
  toggleAllZips,
  toggleZoneZips,
  toggleZip,
  expandedZones,
  setExpandedZones,
  zipDataCount,
}) {
  // State to control the expansion of the top-level "All ZIPs" group
  const [expandAll, setExpandAll] = useState(false);
  // Helper to check if all ZIPs in a zone are selected
  const isZoneFullySelected = (zone) => {
    if (!zones[zone]) return false;
    return zones[zone].every((zone1) =>
      selectedZips.has(zone1.properties.ZCTA5CE10),
    );
  };
  // Check if all ZIPs are selected across all zones
  const allSelected = selectedZips.size === zipDataCount;

  return (
    <>
      <h2>ZIP Selection</h2>

      {/* Top-level "All ZIPs" expandable */}
      <div className="zone-group h4">
        <h6
          onClick={() => setExpandAll((prev) => !prev)}
          style={{ cursor: "pointer", userSelect: "none" }}
        >
          <span style={{ marginRight: 8 }}>
            <FontAwesomeIcon
              icon={expandAll ? faChevronDown : faChevronRight}
            />
          </span>
          {/* Master checkbox to toggle all ZIPs */}
          <input
            type="checkbox"
            checked={allSelected}
            onChange={toggleAllZips}
            onClick={(event) => event.stopPropagation()} // Prevents header click from toggling expandAll when checkbox clicked
            style={{ marginRight: 8 }}
          />
          All ZIPs ({zipDataCount})
        </h6>

        {/* When All ZIPs expanded, show zones */}
        {expandAll && (
          <div className="zones-list" style={{ paddingLeft: 16 }}>
            {Object.keys(zones).map((zone) => (
              <div key={zone} className="zone-group">
                <h6
                  onClick={() =>
                    setExpandedZones((prev) => ({
                      ...prev,
                      [zone]: !prev[zone],
                    }))
                  }
                  style={{ cursor: "pointer", userSelect: "none" }}
                >
                  <span style={{ marginRight: 8 }}>
                    <FontAwesomeIcon
                      icon={
                        expandedZones[zone] ? faChevronDown : faChevronRight
                      }
                    />
                  </span>
                  <input
                    type="checkbox"
                    checked={isZoneFullySelected(zone)}
                    onChange={() => toggleZoneZips(zone)}
                    onClick={(event) => event.stopPropagation()}
                    style={{ marginRight: 8 }}
                  />
                  {zone} ({zones[zone].length})
                </h6>
                {/* Show individual ZIPs if the zone is expanded */}
                {expandedZones[zone] && (
                  <ul className="zip-list" style={{ paddingLeft: 16 }}>
                    {zones[zone].map((feature) => {
                      const zip = feature.properties.ZCTA5CE10;
                      return (
                        <li key={zip}>
                          <label>
                            <input
                              type="checkbox"
                              checked={selectedZips.has(zip)}
                              onChange={() => toggleZip(zip)}
                            />
                            {zip}
                          </label>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
