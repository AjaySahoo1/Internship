// Layer Child Component
import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEye,
  faEyeSlash,
  faChevronDown,
  faChevronRight,
} from "@fortawesome/free-solid-svg-icons";

import "./Layer.css";

export default function Layer({
  zones,
  layerVisibleZips,
  toggleAllLayerZips,
  toggleLayerZone,
  toggleLayerZip,
  expandedZonesLayer,
  setExpandedZonesLayer,
  zipDataCount,
}) {
  // Check if all ZIP codes in a zone are currently visible
  const isZoneFullyVisible = (zone) => {
    return zones[zone]?.every((zone1) =>
      layerVisibleZips.has(zone1.properties.ZCTA5CE10),
    );
  };

  return (
    <div className="layer-panel2">
      {/* Header with button to toggle visibility of all ZIP layers */}
      <div className="layer-panel-header">
        <button
          className="layer-toggle-all-button"
          onClick={toggleAllLayerZips}
        >
          <FontAwesomeIcon
            icon={layerVisibleZips.size === zipDataCount ? faEyeSlash : faEye}
          />
        </button>
        Toggle All
      </div>
      {/* Render each zone with toggle controls and expandable ZIP list */}
      {Object.entries(zones).map(([zone, features]) => (
        <div key={zone} className="zone-layer">
          <div className="zone-header-layer">
            {/* Button to expand/collapse ZIP list for the zone */}
            <button
              className="zone-toggle-button"
              onClick={() =>
                setExpandedZonesLayer((prev) => ({
                  ...prev,
                  [zone]: !prev[zone],
                }))
              }
            >
              <FontAwesomeIcon
                icon={expandedZonesLayer[zone] ? faChevronDown : faChevronRight}
              />
            </button>
            {/* Zone title with visibility toggle */}
            <span
              className="zone-title-layer"
              onClick={() => toggleLayerZone(zone)}
            >
              <FontAwesomeIcon
                icon={isZoneFullyVisible(zone) ? faEye : faEyeSlash}
              />{" "}
              {zone} ({features.length})
            </span>
          </div>
          {/* Conditionally render list of ZIP codes under expanded zone */}
          {expandedZonesLayer[zone] && (
            <div className="zip-list-layer">
              {features.map((feature) => {
                const zip = feature.properties.ZCTA5CE10;
                const isVisible = layerVisibleZips.has(zip);
                return (
                  <div key={zip} className="zip-item-layer">
                    <span
                      className="zip-toggle-button"
                      onClick={() => toggleLayerZip(zip)}
                    >
                      <FontAwesomeIcon icon={isVisible ? faEye : faEyeSlash} />
                    </span>
                    {zip}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
