import React, {useState} from 'react';
import './AllComponents.css';

//Import all child components
import AdditionalNotes from './AdditionalNotes';
import HeaderSection1 from './HeaderSection1';
import HeaderSection2 from './HeaderSection2';
import TabSection from './TabSection';
import RankSection from './RankSection';
import Insights from './Insights'
import InsightWithPopup from './InsightWithPopup';
import TileSection1 from './TileSection1';
import TileSection2 from './TileSection2';
import TileSection3 from './TileSection3';
import CollapsibleMetricsPanel from './CollapsibleMetricsPanel';

//Extra import files for map component
import {useEffect} from 'react';
import Map from './Map';
import { WYOMING_ZIP_ZONES, REGION_COLORS } from '../zip';


import FerringLogo from '../Images/Ferring_Logo.png';

import leftLogo from '../Images/logo-placeholder-image.png';
import rightLogo from '../Images/logo-placeholder-image.png';
import newaward from '../Images/newaward.png'
import newmoneybill from '../Images/newmoneybill.png';

import { faBolt } from '@fortawesome/free-solid-svg-icons';

const AllComponents = () => {

    // Variables to store the value for AdditionalNotes Component
    const additionalNotesArray = [
        "Complete unit testing for module A Complete unit testing for module A Complete unit testing for module A Complete unit testing for module A Complete unit testing for module A Complete unit testing for module A Complete unit testing for module A ",
        "Schedule meeting with stakeholders",
        "Review code for recent PR",
        "Update documentation"
    ];
    const notesHeaderTitle = "Additional Notes";  //Header for the notes section.
    const emptyNotesMessgae = "No Notes Available"; //Message to show when notes is empty or null.

    //Variables to store the value for HeaderSection1 Component
    const reportName = 'Scorecard'
    const reportPeriod = 'Q1 2025';
    const userDetails = [
        "John Doe",
        "Senior Manager",
        "North America",
        "Department: Sales"
    ];

    //Variables to store the value for HeaderSection2 Component
    const buttonLabels = ["My View", "Team Summary", "Executive Overview"];
    const defaultView = buttonLabels[0]; // or choose from props, config, etc.

    const [currentView, setCurrentView] = useState(defaultView);

    // Variables to store the value for TabSection Component
    const tabs = ['My Goals', 'Team Goals', 'Executive Overview'];
    const [activeTab, setActiveTab] = useState(tabs[0]);

    const handleTabClick = (tab) => {
        setActiveTab(tab);
        // Optional: Do something with the selected tab
    };

    // Variables to store the value for RankSection Component
    const rank = 3;
    const total = 50;
    const title = "President Club Rank";

    // Variables to store the value for Insights Component
    const insightTitle = 'INSIGHTS';
    const insightData = [
        {text: 'The indexed attainment for both Ofev-units & Ofev than respective national attainment. Keep it up!'},
        {text: 'Your attainment for Ofev-units and referrals is equal or more than 100%'}
    ];

    // Variables to store the value for InsightWithPopup Component
    const insightWithPopupTitle = 'INSIGHTS';
    const insightWithPopupValue = "Between w.e. 3/8 and w.e 3/29, 2 HCP(s) have reported OFEV Referrals for first time in the last 12 months. Between w.e. 3/8 and w.e 3/29, 2 HCP(s) have reported OFEV Referrals for first time in the last 12 months. Between w.e. 3/8 and w.e 3/29, 2 HCP(s) have reported OFEV Referrals for first time in the last 12 months. Between w.e. 3/8 and w.e 3/29, 2 HCP(s) have reported OFEV Referrals for first time in the last 12 months";
    const insightWithPopupDetails =`1. Dr. Smith submitted 2 referrals on 3/10\n2. Dr. Lee submitted 1 referral on 3/15\n\nBoth providers had no prior referrals in the past 12 months.`;

    // Variables to store the value for TileSection1 and TileSection2 Component
    const tilesData = [
        {Header1: 'Budget', Header2: 'Budget', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget1', Header2: '', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget2', Header2: '', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget3', Header2: 'Budget3', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget4', Header2: 'Budget4', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget5', Header2: 'Budget5', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget6', Header2: 'Budget6', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget7', Header2: 'Budget7', value: '$117,500.00', icon:newmoneybill},
        {Header1: 'Budget8', Header2: 'Budget8', value: '$117,500.00', icon:newmoneybill},
    ];

    // Variables to store the value for TileSection1 and TileSection3 Component
    const highlightedTileData = {
        Header1: 'Budget9', Header2: 'Budget9', value: '$117,500.00', icon:newmoneybill
    };

    // Variables to store the value for CollapsibleMetricsPanel 
    const collapsibleMetricsPanelData = {
        "OFEV-UNIT":{
            "chartValue":{
                "line":["0.00", "25.00", "100.00", "103.00", "175.00", "220.00", "230.00"],
                "xAxis":["74%","75%","100%","101%","125%","180%","280%"],
                "xPoint":"101.00",
                "yPoint":"103.00"
            },
            "prodSeq":"1",
            "section":[
                {"metric": "Weight", "value": "55.00%", "METRIC_SEQ": "1"},
                {"metric": "Indexed Attainment", "value": "101.00%", "METRIC_SEQ": "2"},
                {"metric": "Percent to Target", "value": "103.00%", "METRIC_SEQ": "3"},
                {"metric": "Earnings", "value": "$9,064.00", "METRIC_SEQ": "4"},
                {"metric": "Payout", "value": "$9,064.00", "METRIC_SEQ": "5"},
            ],
            "table":[
                {"metric": "Sales", "value": "5,812.97", "METRIC_SEQ": "1"},
                {"metric": "Goals", "value": "5,729.98", "METRIC_SEQ": "2"},
                {"metric": "Attainment", "value": "101.45%", "METRIC_SEQ": "3"},
                {"metric": "National Attainment", "value": "98.56%", "METRIC_SEQ": "4"},
                {"metric": "Threshold Lower Limit", "value": "95.00%", "METRIC_SEQ": "5"},
                {"metric": "Threshold Upper Limit", "value": "110.00%", "METRIC_SEQ": "6"},
                {"metric": "Indexed Attainment", "value": "101.00%", "METRIC_SEQ": "7"},
                {"metric": "Percent to Target", "value": "103.00%", "METRIC_SEQ": "8"},
                {"metric": "Target Pay", "value": "$8,800.00", "METRIC_SEQ": "9"},
                {"metric": "Earnings", "value": "$9,064.00", "METRIC_SEQ": "10"},
                {"metric": "Eligibility", "value": "100.00%", "METRIC_SEQ": "11"},
                {"metric": "Payout", "value": "$9,064.00", "METRIC_SEQ": "12"},
            ],
        },
        "OFEV-REFERRAL":{
            "chartValue":{
                "line":["0.00", "25.00", "100.00", "103.00", "175.00", "220.00", "230.00"],
                "xAxis":["74%","75%","100%","101%","125%","180%","280%"],
                "xPoint":"101.00",
                "yPoint":"103.00"
            },
            "prodSeq":"2",
            "section":[
                {"metric": "Weight", "value": "55.00%", "METRIC_SEQ": "1"},
                {"metric": "Indexed Attainment", "value": "101.00%", "METRIC_SEQ": "2"},
                {"metric": "Percent to Target", "value": "103.00%", "METRIC_SEQ": "3"},
                {"metric": "Earnings", "value": "$9,064.00", "METRIC_SEQ": "4"},
                {"metric": "Payout", "value": "$9,064.00", "METRIC_SEQ": "5"},
            ],
            "table":[
                {"metric": "Sales", "value": "5,812.97", "METRIC_SEQ": "1"},
                {"metric": "Goals", "value": "5,729.98", "METRIC_SEQ": "2"},
                {"metric": "Attainment", "value": "101.45%", "METRIC_SEQ": "3"},
                {"metric": "National Attainment", "value": "98.56%", "METRIC_SEQ": "4"},
                {"metric": "Threshold Lower Limit", "value": "95.00%", "METRIC_SEQ": "5"},
                {"metric": "Threshold Upper Limit", "value": "110.00%", "METRIC_SEQ": "6"},
                {"metric": "Indexed Attainment", "value": "101.00%", "METRIC_SEQ": "7"},
                {"metric": "Percent to Target", "value": "103.00%", "METRIC_SEQ": "8"},
                {"metric": "Target Pay", "value": "$8,800.00", "METRIC_SEQ": "9"},
                {"metric": "Earnings", "value": "$9,064.00", "METRIC_SEQ": "10"},
                {"metric": "Eligibility", "value": "100.00%", "METRIC_SEQ": "11"},
                {"metric": "Payout", "value": "$9,064.00", "METRIC_SEQ": "12"},
            ],
        },
        "OFEV-MBO":{
            "chartValue":{
                "line":[],
                "xAxis":[],
                "xPoint":"",
                "yPoint":""
            },
            "prodSeq":"1",
            "section":[
                {"metric": "Weight", "value": "55.00%", "METRIC_SEQ": "1"},
                {"metric": "Indexed Attainment", "value": "101.00%", "METRIC_SEQ": "2"},
                {"metric": "Percent to Target", "value": "103.00%", "METRIC_SEQ": "3"},
                {"metric": "Earnings", "value": "$9,064.00", "METRIC_SEQ": "4"},
                {"metric": "Payout", "value": "$9,064.00", "METRIC_SEQ": "5"},
            ],
            "table":[
                {"metric": "Sales", "value": "5,812.97", "METRIC_SEQ": "1"},
                {"metric": "Goals", "value": "5,729.98", "METRIC_SEQ": "2"},
                {"metric": "Attainment", "value": "101.45%", "METRIC_SEQ": "3"},
                {"metric": "National Attainment", "value": "98.56%", "METRIC_SEQ": "4"},
                {"metric": "Threshold Lower Limit", "value": "95.00%", "METRIC_SEQ": "5"},
                {"metric": "Threshold Upper Limit", "value": "110.00%", "METRIC_SEQ": "6"},
            ],
        }
    }

    const [expandedSections, setExpandedSections] = useState({});

    const handleToggle = (key) => {
        setExpandedSections((prev) => ({
        ...prev,
        [key]: !prev[key],
        }));
    };

    const lineChartOptions = {
        chart: {
            type: 'line',
            height: 250
        },
        title: {
            text: 'Payout curve',
            style: { fontSize: '14px', fontWeight: 'bold' }
        },
        yAxis: {
            min: 0,
            title: { text: 'Percent to Target' },
            labels: { enabled: true },
            gridLineWidth: 0,
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: false,
                    style: { fontWeight: 'normal', color: '#000000' }
                },
                marker: {
                    enabled: false
                }
            }
        },
        tooltip: {
            shared: true,
            formatter: function () {
                const attainment = this.x.toFixed(2);
                const percentage = this.y.toFixed(2);
                return `
                    <div style="display: flex; flex-direction: column;">
                        <strong>Indexed Attainment:</strong> ${attainment}%
                        <strong>Percent to Target:</strong> ${percentage}%
                    </div>`;
            }
        },
        legend: {
            enabled: false
        }
    };
    
// Map-related state
const [zipData, setZipData] = useState(null);
const [hcpData, setHcpData] = useState(null);
const [selectedZips, setSelectedZips] = useState(new Set());
const [layerVisibleZips, setLayerVisibleZips] = useState(new Set());
const [showHCP, setShowHCP] = useState(false);

// Fetch data on load
useEffect(() => {
  fetch('../data/wy_wyoming_zip_codes_geo.min.json')
    .then(res => res.json())
    .then(setZipData)
    .catch(console.error);

  fetch('../data/us-hospitals.geojson')
    .then(res => res.json())
    .then(setHcpData)
    .catch(console.error);
}, []);



    return (
        <div style={{ margin: '10px', background: 'white' }}>
            <div>
                {/* Calling additional notes child component */}
                <AdditionalNotes 
                    notes={additionalNotesArray}
                    notesHeader={notesHeaderTitle}
                    emptyMessage={emptyNotesMessgae}
                    useBullets={false} //Whether to display notes as bullet points and by default it is true.
                />
            </div>

            <div style={{marginTop:'10px'}}>
                {/* Calling additional notes child component */}
                <AdditionalNotes 
                    notes={additionalNotesArray}
                    notesHeader={notesHeaderTitle}
                    emptyMessage={emptyNotesMessgae}
                    useBullets={true} //Whether to display notes as bullet points and by default it is true.
                />
            </div>

            <div style={{marginTop:'10px'}}>
                {/* Calling HeaderSection1 child component */}
                <HeaderSection1
                    title={reportName}
                    reportPeriod={reportPeriod}
                    leftLogo={leftLogo}
                    rightLogo={rightLogo}
                    userDetails={userDetails}
                    showRightLogo={false}
                />
            </div>

            <div style={{marginTop:'10px'}}>
                {/* Calling HeaderSection1 child component */}
                <HeaderSection1
                    title={reportName}
                    reportPeriod={reportPeriod}
                    leftLogo={leftLogo}
                    rightLogo={rightLogo}
                    userDetails={userDetails}
                    showRightLogo={true}
                />
            </div>

            <div style={{marginTop:'10px'}}>
                {/* Calling HeaderSection2 child component */}
                <HeaderSection2
                    title="Scorecard"
                    userDetails={userDetails}
                    buttonLabels={buttonLabels}
                    onButtonClick={setCurrentView}
                    defaultView={defaultView}
                />
            </div>

            <div style={{marginTop:'10px'}}>
                {/* Calling TabSection child component */}
                <TabSection
                    tabs={tabs}
                    activeTab={activeTab}
                    handleTabClick={handleTabClick}
                />
            </div>

            {/* Tab-specific content */}
            <div style={{ padding: '10px' }}>
                {activeTab === 'My Goals' && (
                    <div>
                        <h2>My Goals</h2>
                        <p>This is the content for My Goals tab.</p>
                    </div>
                )}
                {activeTab === 'Team Goals' && (
                    <div>
                        <h2>Team Goals</h2>
                        <p>This is the content for Team Goals tab.</p>
                    </div>
                )}
                {activeTab === 'Executive Overview' && (
                    <div>
                        <h2>Executive Overview</h2>
                        <p>This is the content for Executive Overview tab.</p>
                    </div>
                )}
            </div>

            <div style={{marginTop:'10px'}}>
                <RankSection 
                    title={title} 
                    value={rank} 
                    total={total} 
                    image={newaward} 
                />
            </div>

            <div style={{marginTop:'10px'}}>
                <Insights 
                    insights={insightData} 
                    label={insightTitle}
                />
            </div>

            <div style={{marginTop:'10px'}}>
                <InsightWithPopup
                    icon={faBolt}
                    label={insightWithPopupTitle}
                    value={insightWithPopupValue}
                    details={insightWithPopupDetails}
                    onKnowMoreClick={() => console.log("Know more clicked")}
                />
            </div>

            <div style={{marginTop:'10px'}}>
                <TileSection1
                    data={tilesData}
                    tileWidth={180}
                />
            </div>

            <div style={{marginTop:'10px'}}>
                <TileSection2
                    data={tilesData}
                    tileWidth={180} // or 200, 180, whatever fits
                />
            </div>

            <div style={{marginTop:'10px'}}>
                <TileSection3
                    data={tilesData}
                    highlightedData={highlightedTileData}
                    isShowHighlightedTile={true}
                    isEnableScroll={true}         // Enable scroll functionality
                    isShowScrollbar={true}       // Set to false to hide scrollbar
                    highlightedTileWidth={20}     // highlighted section is 20%
                    tileWidth={200}               // each tile has fixed width of 200px
                />
            </div>

            <div style={{marginTop:'10px'}}>
                <CollapsibleMetricsPanel
                    collapsibleItems={collapsibleMetricsPanelData}
                    expandedSections={expandedSections}
                    handleToggle={handleToggle}
                    lineChartOptions={lineChartOptions}
                />
            </div>
            
            {/*Call Map Component*/}
            <div>
                {zipData && hcpData && (
                    <div style={{ height: '600px', marginTop: '20px' }}>
                    <Map
                        zipData={zipData}
                        hcpData={hcpData}
                        selectedZips={selectedZips}
                        setSelectedZips={setSelectedZips}
                        layerVisibleZips={layerVisibleZips}
                        setLayerVisibleZips={setLayerVisibleZips}
                        showHCP={showHCP}
                        setShowHCP={setShowHCP}
                    />
                    </div>
                )}
            </div>



            

            


            

        </div>
    );

};
export default AllComponents;