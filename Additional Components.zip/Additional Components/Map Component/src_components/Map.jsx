// Main map component that renders ZIP code boundaries, HCP markers, and interactive panels for ZIP selection and layer control.
import React, { useState, useEffect, useRef } from "react";
import { MapContainer, TileLayer, GeoJSON } from "react-leaflet";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLayerGroup, faMap } from "@fortawesome/free-solid-svg-icons";
import "leaflet/dist/leaflet.css";
import "./Map.css";
import "./Layer.css";
import { REGION_COLORS, WYOMING_ZIP_ZONES } from "../zip"; //Adjust path wherever needed

import HCPMarker from "./Marker";
import Leaflet from "leaflet";

import MapSidebar from "./MapSidebar";
import Layer from "./Layer";
import Legend from "./Legend";

export default function Map({
  zipData = null,
  hcpData = null,
  selectedZips = new Set(),
  setSelectedZips = () => {},
  layerVisibleZips = new Set(),
  setLayerVisibleZips = () => {},
  showHCP = false,
  setShowHCP = () => {},
}) {
  // State for ZIP and HCP data
  const [localZipData, setLocalZipData] = useState(zipData);
  const [localHcpData, setLocalHcpData] = useState(hcpData);

  // Controls showing/hiding of the layer and legend side panels
  const [showLayerPanel, setShowLayerPanel] = useState(false);
  const [showLegendPanel, setShowLegendPanel] = useState(false);

  // // Keeps latest selectedZips in ref for access inside event handlers
  const selectedZipsRef = useRef(selectedZips);
  useEffect(() => {
    selectedZipsRef.current = selectedZips;
  }, [selectedZips]);

  // Tracks which ZIP zones are expanded in the selection and layer panels
  const [expandedZones, setExpandedZones] = useState({});
  const [expandedZonesLayer, setExpandedZonesLayer] = useState({});

  // Forces re-render of GeoJSON when ZIP layer visibility changes
  const [geoJsonKey, setGeoJsonKey] = useState(Date.now());

  useEffect(() => {
    setGeoJsonKey(Date.now());
  }, [layerVisibleZips]);

  // Organize ZIP features by region zone for grouped display
  const sortedZips = localZipData
    ? [...localZipData.features].sort((zip1, zip2) =>
        (zip1.properties.ZCTA5CE10 || "").localeCompare(
          zip2.properties.ZCTA5CE10 || "",
        ),
      )
    : [];

  const zones = {};
  sortedZips.forEach((feature) => {
    const zip = feature.properties.ZCTA5CE10;
    const zone = WYOMING_ZIP_ZONES[zip] || "Unknown";
    if (!zones[zone]) zones[zone] = [];
    zones[zone].push(feature);
  });

  // Selects or deselects all ZIP codes
  const toggleAllZips = () => {
    if (!localZipData) return;
    if (selectedZips.size === localZipData.features.length) {
      setSelectedZips(new Set());
    } else {
      setSelectedZips(
        new Set(localZipData.features.map((f) => f.properties.ZCTA5CE10)),
      );
    }
  };

  const toggleZoneZips = (zone) => {
    const zoneZipCodes = zones[zone].map((zone1) => zone1.properties.ZCTA5CE10);
    const allSelected = zoneZipCodes.every((zip) => selectedZips.has(zip));
    const newSelected = new Set(selectedZips);

    if (allSelected) {
      zoneZipCodes.forEach((zip) => newSelected.delete(zip));
    } else {
      zoneZipCodes.forEach((zip) => newSelected.add(zip));
    }
    setSelectedZips(newSelected);
  };

  // Toggles selection state of a single ZIP
  const toggleZip = (zip) => {
    const newSelected = new Set(selectedZips);
    if (newSelected.has(zip)) {
      newSelected.delete(zip);
    } else {
      newSelected.add(zip);
    }
    setSelectedZips(newSelected);
  };

  // Toggle visibility of a single ZIP on the overlay layer
  const toggleLayerZip = (zip) => {
    const newVisible = new Set(layerVisibleZips);
    if (newVisible.has(zip)) {
      newVisible.delete(zip);
    } else {
      newVisible.add(zip);
    }
    setLayerVisibleZips(newVisible);
  };

  // Toggle visibility of all ZIPs in a specific zone on the overlay layer
  const toggleLayerZone = (zone) => {
    const zoneZipCodes = zones[zone].map((f) => f.properties.ZCTA5CE10);
    const allVisible = zoneZipCodes.every((zip) => layerVisibleZips.has(zip));
    const newVisible = new Set(layerVisibleZips);

    if (allVisible) {
      zoneZipCodes.forEach((zip) => newVisible.delete(zip));
    } else {
      zoneZipCodes.forEach((zip) => newVisible.add(zip));
    }
    setLayerVisibleZips(newVisible);
  };

  // Toggle visibility of all ZIPs on the overlay layer
  const toggleAllLayerZips = () => {
    if (!localZipData) return;
    if (layerVisibleZips.size === localZipData.features.length) {
      setLayerVisibleZips(new Set());
    } else {
      setLayerVisibleZips(
        new Set(localZipData.features.map((f) => f.properties.ZCTA5CE10)),
      );
    }
  };
  // Style function for main ZIP GeoJSON layer (based on selection and zone color)
  const geoJSONStyle = (feature) => {
    const zip = feature.properties.ZCTA5CE10;
    const isSelected = selectedZips.has(zip);
    const zone = WYOMING_ZIP_ZONES[zip] || "Unknown";
    const color = REGION_COLORS[zone] || "#ccc";

    if (!isSelected) return { fillOpacity: 0, opacity: 0 };

    return {
      color: "black",
      weight: 2,
      fillColor: color,
      fillOpacity: 0.5,
      opacity: 0.5,
    };
  };
  // Style function for overlay ZIP layer (used for visualization only, not selection)
  const geoJSONLayerStyle = (feature) => {
    const zip = feature.properties.ZCTA5CE10;
    const isVisible = layerVisibleZips.has(zip);

    if (!isVisible) return { fillOpacity: 0, opacity: 0, weight: 0 };

    return {
      color: "black",
      weight: 4,
      fillOpacity: 0,
      opacity: 1,
    };
  };
  // Add hover tooltip and interactivity for ZIP layer (selection-dependent)
  const onEachZip = (feature, layer) => {
    const zip = feature.properties.ZCTA5CE10 || "Unknown";
    const zone = WYOMING_ZIP_ZONES[zip] || "Unknown";
    const isSelected = selectedZipsRef.current.has(zip);
    if (!isSelected) {
      layer.bindTooltip(`<strong>ZIP: ${zip}</strong><br/>Zone: ${zone}`, {
        sticky: true,
        direction: "top",
        offset: [0, -10],
        opacity: 0.9,
        className: "custom-tooltip",
      });
    }
    layer.on({
      mouseover: (event) => {
        const layer = event.target;
        const zip = layer.feature.properties.ZCTA5CE10;
        const zone = WYOMING_ZIP_ZONES[zip] || "Unknown";
        const isSelected = selectedZipsRef.current.has(zip);
        const baseColor = REGION_COLORS[zone] || "#ccc";

        layer.setStyle({
          weight: 5,
          color: "#333",
          fillColor: isSelected ? baseColor : "transparent",
          fillOpacity: isSelected ? 0.9 : 0,
        });

        if (
          !Leaflet.Browser.ie &&
          !Leaflet.Browser.opera &&
          !Leaflet.Browser.edge
        ) {
          layer.bringToFront();
        }
        if (isSelected) {
          layer.openTooltip();
        }
      },

      mouseout: (event) => {
        const layer = event.target;
        const zip = layer.feature.properties.ZCTA5CE10;
        const zone = WYOMING_ZIP_ZONES[zip] || "Unknown";
        const isSelected = selectedZipsRef.current.has(zip);

        layer.setStyle({
          weight: isSelected ? 2 : 0,
          color: isSelected ? "black" : "transparent",
          fillOpacity: isSelected ? 0.5 : 0,
          fillColor: isSelected ? REGION_COLORS[zone] || "#ccc" : "transparent",
          opacity: isSelected ? 0.5 : 0,
        });
        if (isSelected) {
          layer.closeTooltip();
        }
      },
    });
  };
  // Tooltip for overlay ZIP layer (always visible if the layer is shown)
  const onEachLayerZip = (feature, layer) => {
    const zip = feature.properties.ZCTA5CE10 || "Unknown";
    const zone = WYOMING_ZIP_ZONES[zip] || "Unknown";
    layer.bindTooltip(
      `<strong>ZIP: ${zip}</strong><br/>Zone: ${zone} (Layer)`,
      {
        sticky: true,
        direction: "top",
        offset: [0, -10],
        opacity: 0.9,
        className: "custom-tooltip",
      },
    );
  };
  // Close layer panel when clicking outside of it
  const layerPanelRef = useRef(null);
  const layerToggleButtonRef = useRef(null);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        layerPanelRef.current &&
        !layerPanelRef.current.contains(event.target) &&
        layerToggleButtonRef.current &&
        !layerToggleButtonRef.current.contains(event.target)
      ) {
        setShowLayerPanel(false);
      }
    };

    if (showLayerPanel) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showLayerPanel]);

  //// Close legend panel when clicking outside of it
  const legendPanelRef = useRef(null);
  const legendToggleButtonRef = useRef(null);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        legendPanelRef.current &&
        !legendPanelRef.current.contains(event.target) &&
        legendToggleButtonRef.current &&
        !legendToggleButtonRef.current.contains(event.target)
      ) {
        setShowLegendPanel(false);
      }
    };

    if (showLegendPanel) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showLegendPanel]);

  // Side panel for selecting ZIPs by zone and toggling HCP visibility
  
  // Layer child component
  

  // Main Leaflet map container with ZIP layers and HCP markers
  return (
    <div className="map-container">
      <div className="sidebar">
            <MapSidebar
          zones={zones}
          selectedZips={selectedZips}
          toggleAllZips={toggleAllZips}
          toggleZoneZips={toggleZoneZips}
          toggleZip={toggleZip}
          expandedZones={expandedZones}
          setExpandedZones={setExpandedZones}
          zipDataCount={localZipData?.features.length || 0}
        />

        <label className="toggle-hcp">
          <input
            type="checkbox"
            checked={showHCP}
            onChange={(event) => setShowHCP(event.target.checked)}
          />
          Show HCPs
        </label>
      </div>

      <MapContainer
        center={[43.0, -107.5]}
        zoom={6}
        style={{ height: "100vh", width: "100%" }}
      >
        <TileLayer
          attribution="&copy; OpenStreetMap contributors"
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
        />
        {/* GeoJSON layer for selected ZIPs */}
        {localZipData && (
          <GeoJSON
            key={geoJsonKey}
            data={localZipData}
            style={geoJSONStyle}
            onEachFeature={onEachZip}
          />
        )}
        {/* Overlay GeoJSON layer for visible ZIPs (used for additional visualization) */}
        {localZipData && (
          <GeoJSON
            key={`${geoJsonKey}-layer`}
            data={localZipData}
            style={geoJSONLayerStyle}
            onEachFeature={onEachLayerZip}
          />
        )}
        {/* Conditionally render HCP markers based on toggle state */}
        {localHcpData && showHCP && (
          <HCPMarker hcpData={localHcpData} zoomThreshold={3} />
        )}

        {/* Floating button to toggle layer visibility control panel */}
        <div className="layer-button-container" ref={layerToggleButtonRef}>
          <button
            className="layer-toggle-button"
            title="Layer Panel"
            onClick={() =>
              setShowLayerPanel((prev) => {
                console.log("Toggling layer panel from", prev, "to", !prev);
                return !prev;
              })
            }
          >
            <FontAwesomeIcon icon={faLayerGroup} size="2x" />
          </button>
        </div>

        {/* Render ZIP visibility control panel */}
        {showLayerPanel && <div ref={layerPanelRef}>
          <Layer
            zones={zones}
            layerVisibleZips={layerVisibleZips}
            toggleAllLayerZips={toggleAllLayerZips}
            toggleLayerZone={toggleLayerZone}
            toggleLayerZip={toggleLayerZip}
            expandedZonesLayer={expandedZonesLayer}
            setExpandedZonesLayer={setExpandedZonesLayer}
            zipDataCount={zipData?.features.length || 0}
          />
          </div>}

        {/* Floating button to toggle legend panel */}
        <div className="legend-button-container" ref={legendToggleButtonRef}>
          <button
            className="legend-toggle-button"
            title="Legend Panel"
            onClick={() =>
              setShowLegendPanel((prev) => {
                console.log("Toggling legend panel from", prev, "to", !prev);
                return !prev;
              })
            }
          >
            <FontAwesomeIcon icon={faMap} size="2x" />
          </button>
        </div>

        {/* Render legend panel showing region color mappings */}
        {showLegendPanel && (
          <div className="legend-wrapper" ref={legendPanelRef}>
            <Legend regionColors={REGION_COLORS} />
          </div>
        )}
      </MapContainer>
    </div>
  );
}
