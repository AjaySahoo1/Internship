// Import React and hooks
import React, { useState } from 'react';

// Import styles
import './Helpdesk.css';

// Import Font Awesome icons
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faUserCircle } from '@fortawesome/free-solid-svg-icons';

/**
 * Helpdesk component
 * Allows users to raise tickets with issue details and attachments.
 * Displays ticket history and supports deletion.
 *
 * Props:
 * - onClose: function to close the Helpdesk modal (typically from parent)
 */
const Helpdesk = ({ onClose }) => {
  // List of available issue types
  const issueTypes = [
    'Login Issue',
    'Page Not Loading',
    'Incorrect Data',
    'Other'
  ];

  // Form input state
  const [issueType, setIssueType] = useState('');
  const [description, setDescription] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [attachmentError, setAttachmentError] = useState('');

  // Ticket state
  const [tickets, setTickets] = useState([]);

  // UI state
  const [message, setMessage] = useState('');
  const [showForm, setShowForm] = useState(true);

  /**
   * Handle file upload
   * - Validates file type and size
   */
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'image/jpeg',
        'image/png'
      ];

      if (!allowedTypes.includes(file.type)) {
        setAttachmentError('❌ Invalid file type. Only PDF, DOC, JPEG, PNG allowed.');
        setAttachment(null);
        return;
      }

      if (file.size > 2 * 1024 * 1024) {
        setAttachmentError('❌ File size should not exceed 2MB.');
        setAttachment(null);
        return;
      }

      setAttachment(file);
      setAttachmentError('');
    }
  };

  /**
   * Handle form submission
   * - Validates and creates a new ticket
   */
  const handleSubmit = (e) => {
    e.preventDefault();

    if (!attachment) {
      setAttachmentError('❌ Attachment is required.');
      return;
    }

    const newTicket = {
      id: Date.now(),
      issueType,
      description,
      attachment,
      status: 'Submitted',
      createdAt: new Date().toLocaleString(),
    };

    setTickets([newTicket, ...tickets]);
    setMessage('✅ Ticket has been raised');

    // Reset form
    setIssueType('');
    setDescription('');
    setAttachment(null);
    setAttachmentError('');
    setShowForm(false);

    setTimeout(() => setMessage(''), 3000);
  };

  /**
   * Delete a ticket
   */
  const handleDelete = (id) => {
    setTickets(tickets.filter(ticket => ticket.id !== id));
  };

  return (
    <div className="helpdesk-container">
      <h2>Facing issues? We are here at your service</h2>

      {/* Close Helpdesk Modal */}
      <button className="helpdesk-close-btn" onClick={onClose}>✖</button>

      {/* Ticket Submission Form */}
      {showForm && (
        <form className="helpdesk-form" onSubmit={handleSubmit}>
          <label>
            Issue Type:
            <select
              value={issueType}
              onChange={(e) => setIssueType(e.target.value)}
              required
            >
              <option value="">-- Select an issue --</option>
              {issueTypes.map((type, index) => (
                <option key={index} value={type}>{type}</option>
              ))}
            </select>
          </label>

          <label>
            Description:
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              required
            />
          </label>

          <label>
            Upload Attachment:
            <input type="file" onChange={handleFileChange} />
            {attachment && <p>Attached: {attachment.name}</p>}
            {attachmentError && (
              <p className="helpdesk-error">{attachmentError}</p>
            )}
          </label>

          <button type="submit">Submit</button>
        </form>
      )}

      {/* Success Message */}
      {message && <p className="helpdesk-message">{message}</p>}

      {/* Ticket History Section */}
      {tickets.length > 0 && (
        <div className="helpdesk-ticket-history">
          <h3>Ticket History</h3>
          <ul>
            {tickets.map(ticket => (
              <li key={ticket.id} className="helpdesk-ticket-item">
                <strong>{ticket.issueType}</strong>
                <p>{ticket.description}</p>
                <p>Status: {ticket.status}</p>
                <p>Created At: {ticket.createdAt}</p>
                {ticket.attachment && <p>Attachment: {ticket.attachment.name}</p>}

                {/* Delete button with Font Awesome icon */}
                <button
                  onClick={() => handleDelete(ticket.id)}
                  className="delete-ticket-btn"
                  title="Delete Ticket"
                >
                  <FontAwesomeIcon icon={faTrash} />
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Button to open form again */}
      {!showForm && (
        <button
          className="helpdesk-new-ticket-btn"
          onClick={() => setShowForm(true)}
        >
          + New Ticket
        </button>
      )}
    </div>
  );
};

export default Helpdesk;
