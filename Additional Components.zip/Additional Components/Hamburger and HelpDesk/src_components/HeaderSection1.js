import React from 'react';
import './HeaderSection1.css'; // Custom styling for header
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';
import HamburgerMenu from './HamburgerMenu'; // Reusable menu component

/**
 * HeaderSection1 Component
 *
 * This component creates a flexible and responsive header section.
 * It includes left and right logos, a central title block, user info,
 * and a hamburger menu that gives access to saved layouts and Helpdesk.
 *
 * Props:
 * - reportPeriod:        Display period info like "Q2 2025"
 * - title:               Main title like "Sales Dashboard"
 * - leftLogo:            Path or URL to the left logo
 * - rightLogo:           Path or URL to the right logo (optional)
 * - userDetails:         Array of strings like ["John Doe", "Sales Manager"]
 * - showRightLogo:       Boolean to conditionally show right logo and vertical line
 * - onHelpdeskClick:     Function triggered when Helpdesk is clicked from the menu
 * - savedViewsLabel:     Label for the saved views section in the menu
 * - savedLayouts:        Array of saved layout/view names
 * - onLayoutSelect:      Callback when a layout is selected from the menu
 * - helpdeskLabel:       Label for the Helpdesk item in the menu
 * - showHamburgerMenu:   Boolean to toggle visibility of the hamburger menu (default: true)
 */

const HeaderSection1 = ({
  reportPeriod,
  title,
  leftLogo,
  rightLogo,
  userDetails = [],
  showRightLogo = true,
  onHelpdeskClick = () => {},
  savedViewsLabel = 'Saved Views',
  savedLayouts = [],
  onLayoutSelect = () => {},
  helpdeskLabel = 'Helpdesk',
  showHamburgerMenu = true,  // New prop to show/hide hamburger menu
}) => {
  return (
    <div className="header-section1-container">
      
      {/* Left container: optional left logo and conditional hamburger menu */}
      <div className="header-section1-left-container">
        
        {/* Render left logo if provided */}
        {leftLogo && (
          <img
            src={leftLogo}
            alt="left logo"
            className="header-section1-icon"
          />
        )}

        {/* Conditionally render hamburger menu based on showHamburgerMenu prop */}
        {showHamburgerMenu && (
          <div className="header-section1-hamburger-container">
            <HamburgerMenu
              savedViewsLabel={savedViewsLabel}
              savedViews={savedLayouts}
              onLayoutSelect={onLayoutSelect}
              helpdeskLabel={helpdeskLabel}
              onHelpdeskClick={onHelpdeskClick}
            />
          </div>
        )}
      </div>

      {/* Center container: dashboard title and report period */}
      <div className="header-section1-center-container">
        <p className="header-section1-center-name">{title}</p>
        <p className="header-section1-center-quarter">{reportPeriod}</p>
      </div>

      {/* Right container: user details, user icon, and optional right logo */}
      <div className="header-section1-right-container">
        
        {/* Display each user detail as a separate paragraph */}
        <div className="header-section1-right-user-details">
          {userDetails.map((detail, index) => (
            <p key={index} className="header-section1-right-user">
              {detail}
            </p>
          ))}
        </div>

        {/* Static user icon */}
        <div>
          <FontAwesomeIcon
            icon={faUserCircle}
            className="header-section1-right-user-icon"
            style={{ color: '#0f73be' }}
          />
        </div>

        {/* Optional vertical line shown if showRightLogo is true */}
        {showRightLogo && <div className="header-section1-right-vertical-line"></div>}

        {/* Optional right logo shown if showRightLogo is true and rightLogo prop is provided */}
        {showRightLogo && rightLogo && (
          <img
            src={rightLogo}
            alt="right logo"
            className="header-section1-icon"
          />
        )}
      </div>
    </div>
  );
};

export default HeaderSection1;
