// Import React and necessary hooks
import React, { useState } from 'react';

// Import component-specific CSS styles
import './HamburgerMenu.css';

// Import FontAwesome icons used in the menu
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faChevronDown } from '@fortawesome/free-solid-svg-icons';

// Import the Helpdesk component (modal that shows when Helpdesk is opened)
import Helpdesk from './Helpdesk';

/**
 * HamburgerMenu component displays a collapsible menu typically used in mobile or compact layouts.
 * It supports nested saved views and opens a Helpdesk modal.
 *
 * Props:
 * - savedViews: Array of strings representing saved layout/view names.
 * - onHelpdeskClick: Optional callback triggered when Helpdesk is opened.
 */
const HamburgerMenu = ({
  savedViews = [],          // Array of saved view names like ['Layout 1', 'Layout 2']
  onHelpdeskClick,          // Optional callback when Helpdesk opens
}) => {
  // State to control visibility of the main hamburger menu
  const [menuOpen, setMenuOpen] = useState(false);

  // State to control visibility of the nested "Saved Views" submenu
  const [savedViewsOpen, setSavedViewsOpen] = useState(false);

  // State to control visibility of the Helpdesk modal
  const [helpdeskOpen, setHelpdeskOpen] = useState(false);

  // Toggle the hamburger menu open/close
  const toggleMenu = () => setMenuOpen(prev => !prev);

  // Toggle the nested saved views submenu open/close
  const toggleSavedViews = () => setSavedViewsOpen(prev => !prev);

  // Opens the Helpdesk modal and closes the hamburger menu
  const openHelpdesk = () => {
    if (onHelpdeskClick) onHelpdeskClick();   // Call optional parent handler
    setHelpdeskOpen(true);                    // Show Helpdesk modal
    setMenuOpen(false);                       // Close hamburger menu
  };

  return (
    <div className="hamburger-menu-container">
      {/* Hamburger icon to toggle the menu */}
      <FontAwesomeIcon
        icon={faBars}
        className="hamburger-menu-icon"
        onClick={toggleMenu}
      />

      {/* Dropdown menu that appears when hamburger menu is open */}
      {menuOpen && (
        <div className="hamburger-menu-dropdown">
          <ul>
            {/* Saved Views item with nested submenu */}
            <li onClick={toggleSavedViews} className="menu-item">
              Saved Views <FontAwesomeIcon icon={faChevronDown} />
              
              {/* Show submenu if savedViewsOpen is true */}
              {savedViewsOpen && (
                <ul className="submenu">
                  {/* Render each saved view as a submenu item */}
                  {savedViews.length > 0 ? (
                    savedViews.map((view, index) => (
                      <li key={index} className="submenu-item">{view}</li>
                    ))
                  ) : (
                    <li className="submenu-item">No saved views</li>
                  )}
                </ul>
              )}
            </li>

            {/* Helpdesk item - opens the modal */}
            <li onClick={openHelpdesk} className="menu-item">Helpdesk</li>
          </ul>
        </div>
      )}

      {/* Helpdesk Modal and Backdrop - shown when helpdeskOpen is true */}
      {helpdeskOpen && (
        <>
          {/* Backdrop overlay - closes modal when clicked */}
          <div
            className="hamburger-helpdesk-backdrop"
            onClick={() => setHelpdeskOpen(false)}
          />

          {/* Modal content - shows the Helpdesk component */}
          <div className="hamburger-helpdesk-modal">
            <Helpdesk onClose={() => setHelpdeskOpen(false)} />
          </div>
        </>
      )}
    </div>
  );
};

// Export component to be used in other parts of the application
export default HamburgerMenu;
